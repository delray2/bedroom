// UI Manager Class for handling modal interactions and bubble chart functionality
class UIManager {
  constructor() {
    this.initializeEventListeners();
  }

  initializeEventListeners() {
    // Side button event listeners
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('side-btn')) {
        const action = e.target.getAttribute('data-action');
        if (action) {
          this.handleSideButtonClick(action);
        }
      }
    });

    // Theme toggle
    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
      themeToggle.addEventListener('click', () => this.toggleTheme());
    }
  }

  handleSideButtonClick(action) {
    switch (action) {
      case 'showBubbleChartModal':
        this.showBubbleChartModal();
        break;
      case 'showTvModal':
        this.showModal('TV Controls', 'TV controls coming soon...');
        break;
      case 'showVacuumModal':
        this.showModal('Vacuum Controls', 'Vacuum controls coming soon...');
        break;
      case 'showCameraModal':
        if (typeof showCameraModal === 'function') {
          showCameraModal();
        }
        break;
      case 'showMusicModal':
        this.showModal('Music Player', 'Music controls coming soon...');
        break;
    }
  }

  showBubbleChartModal() {
    const bubbles = [
      { label: 'Table', id: '452', icon: '💡' },
      { label: 'Fan 1', id: '449', icon: '💡' },
      { label: 'Fan 2', id: '446', icon: '💡' },
      { label: 'LR Wall', id: '470', icon: '💡' },
      { label: 'Scenes', id: 'scenes', icon: '🎬' },
      { label: 'WLED Effects', id: 'wled', icon: '✨' },
      { label: 'Global', id: 'global', icon: '🌐' }
    ];

    let html = `<div style='position:relative;width:420px;height:420px;display:flex;align-items:center;justify-content:center;'>`;
    html += `<div style='position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:2;'>
      <div style='width:120px;height:120px;background:#ffd600;color:#232526;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.2em;font-weight:bold;box-shadow:0 2px 16px #0006;'>Living Room<br>Lights</div>
    </div>`;

    const radius = 150;
    const centerX = 210, centerY = 210;
    
    bubbles.forEach((bubble, i) => {
      const angle = (i / bubbles.length) * 2 * Math.PI;
      const x = centerX + radius * Math.cos(angle) - 60;
      const y = centerY + radius * Math.sin(angle) - 60;
      
      html += `<button onclick="uiManager.handleBubbleClick('${bubble.label}','${bubble.id}')" 
                       style="position:absolute;left:${x}px;top:${y}px;width:100px;height:100px;border-radius:50%;background:#232526;color:#ffffff;font-size:1.1em;display:flex;flex-direction:column;align-items:center;justify-content:center;box-shadow:0 0 0 2px rgba(0,0,0,0.8),0 2px 12px rgba(0,0,0,0.8);border:none;cursor:pointer;z-index:1;transition:transform 0.2s;">
        <span style='font-size:2em;'>${bubble.icon}</span>
        ${bubble.label}
      </button>`;
    });

    html += `</div>`;
    
    this.showModal(html, {
      triggerSelector: '.side-btn[title="Lights"]',
      isBubble: true
    });
  }

  handleBubbleClick(label, id) {
    if (['452','449','446','470'].includes(id)) {
      this.showDeviceModal(label, id, true);
    } else if (id === 'scenes') {
      this.showScenesModal();
    } else if (id === 'wled') {
      this.showWledModal();
    } else {
      this.showModal(`<h2>${label}</h2><p>Controls for <b>${label}</b> coming soon...</p>`, {
        showBack: true,
        triggerSelector: '.side-btn[title="Lights"]',
        isBubble: true,
        hideClose: true
      });
    }
  }

  showScenesModal() {
    // Import sceneManager dynamically
    import('./scenes.js').then(({ sceneManager }) => {
      const html = sceneManager.getScenePreviewHTML();
      this.showModal(html, {
        showBack: true,
        triggerSelector: '.side-btn[title="Lights"]',
        isBubble: true,
        hideClose: true
      });
    });
  }

  showDeviceModal(label, deviceId, showBack = false) {
    this.showModal(`<h2>${label}</h2><div id='deviceControls'><em>Loading...</em></div>`, {
      showBack,
      triggerSelector: '.side-btn[title="Lights"]'
    });

    // Load device controls
    this.loadDeviceControls(deviceId, showBack);
  }

  async loadDeviceControls(deviceId, showBack) {
    try {
      const device = await window.apiService.getDeviceStatus(deviceId);
      this.renderDeviceControls(device, deviceId, showBack);
    } catch (error) {
      document.getElementById('deviceControls').innerHTML = 
        `<span style='color:red'>Failed to load device state: ${error.message}</span>`;
    }
  }

  renderDeviceControls(device, deviceId, showBack) {
    const capabilities = this.getDeviceCapabilities(deviceId);
    if (!capabilities) {
      document.getElementById('deviceControls').innerHTML = 
        `<span style='color:red'>Unknown device type</span>`;
      return;
    }

    // Render device controls based on capabilities
    let html = '';
    
    // Power toggle
    const isOn = device.attributes?.switch === 'on';
    html += `<div style="text-align: center; margin-bottom: 20px;">
      <button onclick="uiManager.sendDeviceCommand('${deviceId}', '${isOn ? 'off' : 'on'}')" 
              style="background: ${isOn ? '#4caf50' : '#f44336'}; color: white; border: none; padding: 10px 20px; border-radius: 5px; font-size: 1.1em;">
        ${isOn ? 'Turn Off' : 'Turn On'}
      </button>
    </div>`;

    // Brightness slider
    if (capabilities.includes('SwitchLevel')) {
      const level = device.attributes?.level || 0;
      html += `<div style="margin: 10px 0;">
        <label>Brightness: ${level}%</label>
        <input type="range" min="1" max="100" value="${level}" 
               onchange="uiManager.sendDeviceCommand('${deviceId}', 'setLevel', this.value)"
               style="width: 100%;">
      </div>`;
    }

    // Color controls
    if (capabilities.includes('ColorControl')) {
      const hue = device.attributes?.hue || 0;
      const saturation = device.attributes?.saturation || 0;
      
      html += `<div style="margin: 10px 0;">
        <label>Hue: ${hue}</label>
        <input type="range" min="0" max="100" value="${hue}" 
               onchange="uiManager.sendDeviceCommand('${deviceId}', 'setHue', this.value)"
               style="width: 100%;">
      </div>`;
      
      html += `<div style="margin: 10px 0;">
        <label>Saturation: ${saturation}</label>
        <input type="range" min="0" max="100" value="${saturation}" 
               onchange="uiManager.sendDeviceCommand('${deviceId}', 'setSaturation', this.value)"
               style="width: 100%;">
      </div>`;
    }

    document.getElementById('deviceControls').innerHTML = html;
  }

  getDeviceCapabilities(deviceId) {
    const deviceMap = {
      '452': ['Switch', 'SwitchLevel', 'ColorControl'],
      '449': ['Switch', 'SwitchLevel', 'ColorControl'],
      '446': ['Switch', 'SwitchLevel', 'ColorControl'],
      '470': ['Switch', 'SwitchLevel', 'ColorControl']
    };
    return deviceMap[deviceId] || [];
  }

  async sendDeviceCommand(deviceId, command, value) {
    try {
      const data = await window.apiService.sendDeviceCommand(deviceId, command, value);
      
      // Refresh device controls
      this.loadDeviceControls(deviceId, true);
      
      console.log('Device command response:', data);
    } catch (error) {
      console.error('Failed to send device command:', error);
    }
  }

  showWledModal() {
    this.showModal(`<h2>WLED Effects</h2><p>LR Wall WLED controls coming soon...</p>`, {
      showBack: true,
      triggerSelector: '.side-btn[title="Lights"]',
      isBubble: true,
      hideClose: true
    });
  }

  showModal(content, options = {}) {
    const modalBg = document.getElementById('modalBg');
    const modalContent = document.getElementById('modalContent');
    const modalBody = document.getElementById('modalBody');
    const backBtn = document.getElementById('backModal');
    const closeBtn = document.getElementById('closeModal');

    // Set content
    modalBody.innerHTML = content;

    // Show/hide back button
    if (backBtn) {
      backBtn.style.display = options.showBack ? 'block' : 'none';
    }

    // Show/hide close button
    if (closeBtn) {
      closeBtn.style.display = options.hideClose ? 'none' : 'block';
    }

    // Show modal
    modalBg.style.display = 'flex';
    modalBg.classList.add('visible');
    modalContent.style.transform = 'scale(1) translate(0px)';
    modalContent.style.opacity = '1';
  }

  toggleTheme() {
    const body = document.body;
    const themeToggle = document.getElementById('themeToggle');
    
    if (body.classList.contains('dark-theme')) {
      body.classList.remove('dark-theme');
      themeToggle.textContent = '🌙';
      localStorage.setItem('theme', 'light');
    } else {
      body.classList.add('dark-theme');
      themeToggle.textContent = '☀️';
      localStorage.setItem('theme', 'dark');
    }
  }
}

// Initialize UI Manager
const uiManager = new UIManager();

// Load saved theme
document.addEventListener('DOMContentLoaded', () => {
  const savedTheme = localStorage.getItem('theme');
  const themeToggle = document.getElementById('themeToggle');
  
  if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
    if (themeToggle) {
      themeToggle.textContent = '☀️';
    }
  }
}); 