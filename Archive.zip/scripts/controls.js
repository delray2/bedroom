// --- TV Modal (50" Roku TV, deviceId 474) ---
function showTvModal() {
  const tvId = '474';
  let html = `<div class="modal-header">TV Controls</div>
    <div class="circular-buttons">`;
  
  const tvButtons = [
    {label:'Power', cmd:'power', icon:'⏻', api:'off'},
    {label:'On', cmd:'on', icon:'🔛', api:'on'},
    {label:'Home', cmd:'home', icon:'🏠', api:'home'},
    {label:'Mute', cmd:'mute', icon:'🔇', api:'mute'},
    {label:'Unmute', cmd:'unmute', icon:'🔊', api:'unmute'},
    {label:'Vol +', cmd:'volup', icon:'🔼', api:'volumeUp'},
    {label:'Vol -', cmd:'voldown', icon:'🔽', api:'volumeDown'},
    {label:'Ch +', cmd:'chup', icon:'📺+', api:'channelUp'},
    {label:'Ch -', cmd:'chdown', icon:'📺-', api:'channelDown'},
    {label:'Input', cmd:'input', icon:'🔀', api:'setInputSource'},
    {label:'Play', cmd:'play', icon:'▶️', api:'play'},
    {label:'Pause', cmd:'pause', icon:'⏸️', api:'pause'},
    {label:'Stop', cmd:'stop', icon:'⏹️', api:'stop'}
  ];
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < tvButtons.length; i++) {
    const angle = (i / tvButtons.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button control-button" style="left: ${x}px; top: ${y}px;" onclick='tvSendCommand("${tvButtons[i].api}")'>
      <div class="icon">${tvButtons[i].icon}</div>
      <div class="label">${tvButtons[i].label}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='tvFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModalContent(html, true, '.side-btn[title="TV"]');
}

window.tvSendCommand = function(apiCmd) {
  const tvId = '474';
  let url = `${MAKER_API_BASE}/devices/${tvId}/${apiCmd}?access_token=${ACCESS_TOKEN}`;
  fetch(url).then(r => r.json()).then(() => {
    const feedback = document.getElementById('tvFeedback');
    if (feedback) {
      feedback.textContent = `TV command "${apiCmd}" sent!`;
      feedback.style.display = 'block';
      setTimeout(() => { feedback.style.display = 'none'; }, 1800);
    }
    showToast(`TV command "${apiCmd}" sent!`, 'success');
  }).catch(err => {
    console.error('Failed to send TV command:', err);
    showToast(`Failed to send TV command: ${err.message}`, 'error');
  });
}

// --- Vacuum Modal ---
function showVacuumModal() {
  let html = `<div class="modal-header">Roborock Vacuum</div>
    <div class="circular-buttons">`;
  
  const buttons = [
    { icon: '🧹', label: 'Start', onclick: 'vacuumCommand("appClean")' },
    { icon: '🏠', label: 'Home', onclick: 'vacuumCommand("appDock")' },
    { icon: '⏸️', label: 'Pause', onclick: 'vacuumCommand("appPause")' },
    { icon: '🎬', label: 'Scenes', onclick: 'showVacuumScenesModal()' }
  ];
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < buttons.length; i++) {
    const angle = (i / buttons.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button control-button" style="left: ${x}px; top: ${y}px;" onclick='${buttons[i].onclick}'>
      <div class="icon">${buttons[i].icon}</div>
      <div class="label">${buttons[i].label}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='vacuumFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModalContent(html, true, '.side-btn[title="Vacuum"]');
}

window.vacuumCommand = function(cmd) {
  const vacuumId = '298';
  let url = `${MAKER_API_BASE}/devices/${vacuumId}/${cmd}?access_token=${ACCESS_TOKEN}`;
  fetch(url).then(r => r.json()).then(() => {
    const feedback = document.getElementById('vacuumFeedback');
    if (feedback) {
      feedback.textContent = `Vacuum command "${cmd}" sent!`;
      feedback.style.display = 'block';
      setTimeout(() => { feedback.style.display = 'none'; }, 1800);
    }
    showToast(`Vacuum command "${cmd}" sent!`, 'success');
  }).catch(err => {
    console.error('Failed to send vacuum command:', err);
    showToast(`Failed to send vacuum command: ${err.message}`, 'error');
  });
}

// Vacuum Scenes Modal
window.showVacuumScenesModal = function() {
  const scenes = [
    {name:'Full Cleaning', id: '2739622'},
    {name:'Vac + Mop', id: '2739711'},
    {name:'Deep', id: '2739712'},
    {name:'Intensive', id: '2739713'},
    {name:'Deep+', id: '2739715'},
    {name:'Living Room', id: '2781198'},
    {name:'Vac + Mop3', id: '3162708'}
  ];
  
  let html = `<div class="modal-header">Vacuum Scenes</div>
    <div class="circular-buttons">`;
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < scenes.length; i++) {
    const angle = (i / scenes.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button control-button" style="left: ${x}px; top: ${y}px;" onclick='vacuumScene("${scenes[i].id}","${scenes[i].name}")'>
      <div class="icon">🎬</div>
      <div class="label">${scenes[i].name}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='vacuumSceneFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModalContent(html, true, '.side-btn[title="Vacuum"]');
}

window.vacuumScene = function(sceneId, sceneName) {
  const vacuumId = '298';
  let url = `${MAKER_API_BASE}/devices/${vacuumId}/appScene/${sceneId}?access_token=${ACCESS_TOKEN}`;
  fetch(url).then(r => r.json()).then(() => {
    const feedback = document.getElementById('vacuumSceneFeedback');
    if (feedback) {
      feedback.textContent = `Scene "${sceneName}" started!`;
      feedback.style.display = 'block';
      setTimeout(() => { feedback.style.display = 'none'; }, 1800);
    }
    showToast(`Vacuum scene "${sceneName}" started!`, 'success');
  }).catch(err => {
    console.error('Failed to start vacuum scene:', err);
    showToast(`Failed to start scene: ${err.message}`, 'error');
  });
} 