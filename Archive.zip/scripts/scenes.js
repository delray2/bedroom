// Enhanced Scene System with Individual Bulb Control and Calculated Color Palettes
const lifxScenes = [
  {
    name: 'White',
    gradient: 'linear-gradient(90deg, #ffffff 0%, #f5f5f5 100%)',
    bulbs: [
      { deviceId: '449', color: '#ffffff', brightness: 100, temp: 4000 }, // Fan 1
      { deviceId: '446', color: '#ffffff', brightness: 100, temp: 4000 }, // Fan 2
      { deviceId: '452', color: '#ffffff', brightness: 100, temp: 4000 }  // Table
    ],
    wled: {
      palette: 0,  // Default palette
      effect: 0,   // Solid
      brightness: 128,
      color: '#ffffff'
    }
  },
  {
    name: 'Sunset',
    gradient: 'linear-gradient(90deg, #ff4500 0%, #ff6347 25%, #ffd700 50%, #ff8c00 75%, #dc143c 100%)',
    bulbs: [
      { deviceId: '449', color: '#ff4500', brightness: 80, temp: 2700 },  // Fan 1 - Red-orange
      { deviceId: '446', color: '#ffd700', brightness: 70, temp: 3000 },  // Fan 2 - Gold
      { deviceId: '452', color: '#ff6347', brightness: 60, temp: 3500 }   // Table - Tomato red
    ],
    wled: {
      palette: 45, // Sunset palette
      effect: 0,   // Solid
      brightness: 128
    }
  },
  {
    name: 'Ocean',
    gradient: 'linear-gradient(90deg, #000080 0%, #006994 25%, #00bfff 50%, #87ceeb 75%, #e0f6ff 100%)',
    bulbs: [
      { deviceId: '449', color: '#000080', brightness: 85, temp: 6500 },  // Fan 1 - Navy blue
      { deviceId: '446', color: '#00bfff', brightness: 75, temp: 7000 },  // Fan 2 - Deep sky blue
      { deviceId: '452', color: '#87ceeb', brightness: 65, temp: 6000 }   // Table - Sky blue
    ],
    wled: {
      palette: 37, // Tropical palette
      effect: 0,   // Solid
      brightness: 128
    }
  },
  {
    name: 'Forest',
    gradient: 'linear-gradient(90deg, #2d5016 0%, #4a7c59 25%, #ffffff 50%, #d4a574 75%, #8b4513 100%)',
    bulbs: [
      { deviceId: '449', color: '#2d5016', brightness: 80, temp: 5000 },  // Fan 1 - Dark green
      { deviceId: '446', color: '#4a7c59', brightness: 70, temp: 5500 },  // Fan 2 - Forest green
      { deviceId: '452', color: '#ffffff', brightness: 60, temp: 5200 }   // Table - White
    ],
    wled: {
      palette: 55, // Forest palette
      effect: 0,   // Solid
      brightness: 128
    }
  },
  {
    name: 'Candlelight',
    gradient: 'linear-gradient(90deg, #ffd452 0%, #ffb347 50%, #ff6961 100%)',
    bulbs: [
      { deviceId: '449', color: '#ffd452', brightness: 60, temp: 2200 },  // Fan 1 - Warm yellow
      { deviceId: '446', color: '#ffb347', brightness: 50, temp: 2500 },  // Fan 2 - Orange
      { deviceId: '452', color: '#ff6961', brightness: 40, temp: 2800 }   // Table - Soft red
    ],
    wled: {
      palette: 65, // Party palette
      effect: 0,   // Solid
      brightness: 100
    }
  },
  {
    name: 'Magenta Dream',
    gradient: 'linear-gradient(90deg, #ff61a6 0%, #a18cd1 50%, #4a90e2 100%)',
    bulbs: [
      { deviceId: '449', color: '#ff61a6', brightness: 75, temp: 3500 },  // Fan 1 - Magenta
      { deviceId: '446', color: '#a18cd1', brightness: 65, temp: 4000 },  // Fan 2 - Purple
      { deviceId: '452', color: '#4a90e2', brightness: 55, temp: 4500 }   // Table - Blue
    ],
    wled: {
      palette: 0,  // Rainbow palette
      effect: 0,   // Solid
      brightness: 128
    }
  },
  {
    name: 'Aurora',
    gradient: 'linear-gradient(90deg, #00ff87 0%, #00ffff 20%, #0080ff 40%, #8000ff 60%, #ff0080 80%, #ffff00 100%)',
    bulbs: [
      { deviceId: '449', color: '#00ff87', brightness: 70, temp: 5000 },  // Fan 1 - Spring green
      { deviceId: '446', color: '#00ffff', brightness: 60, temp: 6000 },  // Fan 2 - Cyan
      { deviceId: '452', color: '#8000ff', brightness: 50, temp: 7000 }   // Table - Purple
    ],
    wled: {
      palette: 0,  // Rainbow palette
      effect: 51,  // Colorloop
      brightness: 128
    }
  },
  {
    name: 'Cozy',
    gradient: 'linear-gradient(90deg, #ff9a9e 0%, #fecfef 50%, #fecfef 100%)',
    bulbs: [
      { deviceId: '449', color: '#ff9a9e', brightness: 65, temp: 3000 },  // Fan 1 - Soft pink
      { deviceId: '446', color: '#fecfef', brightness: 55, temp: 3200 },  // Fan 2 - Light pink
      { deviceId: '452', color: '#ffb3ba', brightness: 45, temp: 3100 }   // Table - Medium pink
    ],
    wled: {
      palette: 45, // Sunset palette
      effect: 0,   // Solid
      brightness: 80
    }
  }
];

// WLED Device IPs - Direct HTTP API control
const WLED_DEVICES = {
  'lrwall': '192.168.4.24'   // LRWall WLED device - direct HTTP API
};

function showScenesModal() {
  let html = `<div class="modal-header">Choose a Scene</div>
    <div class="circular-buttons">`;
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < lifxScenes.length; i++) {
    const angle = (i / lifxScenes.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button scene-button" style="left: ${x}px; top: ${y}px;" onclick='applyLifxScene("${lifxScenes[i].name}")'>
      <div class="icon">🎨</div>
      <div class="label">${lifxScenes[i].name}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='sceneFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModal(html, true);
}

// Enhanced Scene Application with Individual Bulb Control and WLED Gradient
window.applyLifxScene = async function(sceneName) {
  const scene = lifxScenes.find(s => s.name === sceneName);
  if (!scene) {
    showToast('Scene not found', 'error');
    return;
  }
  
  try {
    // Create gradient from scene palette for WLED
    const gradientColors = scene.bulbs.map(bulb => bulb.color);
    const gradientString = gradientColors.join(',');
    
    // Apply to individual LIFX bulbs with calculated colors
    const bulbPromises = scene.bulbs.map(bulb => {
      // Convert hex color to HSL for LIFX
      const hex = bulb.color.replace('#', '');
      const r = parseInt(hex.substr(0, 2), 16) / 255;
      const g = parseInt(hex.substr(2, 2), 16) / 255;
      const b = parseInt(hex.substr(4, 2), 16) / 255;
      
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const l = (max + min) / 2;
      
      let h, s;
      if (max === min) {
        h = s = 0; // achromatic
      } else {
        const d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        switch (max) {
          case r: h = (g - b) / d + (g < b ? 6 : 0); break;
          case g: h = (b - r) / d + 2; break;
          case b: h = (r - g) / d + 4; break;
        }
        h /= 6;
      }
      
      // Convert to LIFX format (0-100 for hue, 0-100 for saturation)
      const hue = Math.round(h * 100);
      const saturation = Math.round(s * 100);
      
      // Send commands to individual bulb
      const promises = [
        // Set color
        fetch(`${MAKER_API_BASE}/devices/${bulb.deviceId}/setColor/${encodeURIComponent(JSON.stringify({hue: hue, saturation: saturation, level: bulb.brightness}))}?access_token=${ACCESS_TOKEN}`),
        // Set brightness
        fetch(`${MAKER_API_BASE}/devices/${bulb.deviceId}/setLevel/${bulb.brightness}?access_token=${ACCESS_TOKEN}`),
        // Turn on
        fetch(`${MAKER_API_BASE}/devices/${bulb.deviceId}/on?access_token=${ACCESS_TOKEN}`)
      ];
      
      return Promise.all(promises);
    });
    
    // Apply to WLED device with gradient and Puddles effect
    const wledPromises = [
      // Set custom gradient and apply Puddles effect (FX=89 is Puddles)
      fetch(`http://${WLED_DEVICES.lrwall}/win&CL=${gradientString}&FX=89&A=${scene.wled.brightness}&SA=0&SB=300&SC=1&SE=1`)
    ];
    
    // Wait for all promises to complete with 1-second duration for smooth transitions
    await Promise.all([...bulbPromises.flat(), ...wledPromises]);
    
    showToast(`Scene "${sceneName}" applied successfully!`, 'success');
    
    // Update UI feedback
    const feedback = document.getElementById('sceneFeedback');
    if (feedback) {
      feedback.textContent = `Scene "${sceneName}" applied!`;
      feedback.style.display = 'block';
      setTimeout(() => { feedback.style.display = 'none'; }, 1800);
    }
    
  } catch (error) {
    console.error('Failed to apply scene:', error);
    showToast(`Failed to apply scene: ${error.message}`, 'error');
  }
}

// WLED Effects Modal with Bubble Theme
function showWledEffectsModal() {
  let html = `<div class="modal-header">WLED Effects</div>
    <div class="circular-buttons">`;
  
  const buttons = [
    { icon: '🎨', label: 'Palettes', onclick: 'showWledPalettesModal()' },
    { icon: '✨', label: 'Effects', onclick: 'showWledFxModal()' }
  ];
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < buttons.length; i++) {
    const angle = (i / buttons.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button wled-button" style="left: ${x}px; top: ${y}px;" onclick='${buttons[i].onclick}'>
      <div class="icon">${buttons[i].icon}</div>
      <div class="label">${buttons[i].label}</div>
    </button>`;
  }
  
  html += `</div>`;
  
  showModal(html, true);
}

// WLED Palettes Modal
window.showWledPalettesModal = function() {
  const palettes = [
    {name:'Sunset', id: 45},
    {name:'Tropical', id: 37},
    {name:'Party', id: 65},
    {name:'Forest', id: 55},
    {name:'Rainbow', id: 0}
  ];
  
  let html = `<div class="modal-header">WLED Palettes</div>
    <div class="circular-buttons">`;
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < palettes.length; i++) {
    const angle = (i / palettes.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button wled-button" style="left: ${x}px; top: ${y}px;" onclick='applyWledPalette(${palettes[i].id},"${palettes[i].name}")'>
      <div class="icon">🎨</div>
      <div class="label">${palettes[i].name}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='wledFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModal(html, true);
}

window.applyWledPalette = function(id, name) {
  // Apply to LRWall WLED device
  fetch(`http://${WLED_DEVICES.lrwall}/win&FP=${id}`)
    .then(() => {
      const feedback = document.getElementById('wledFeedback');
      if (feedback) {
        feedback.textContent = `Palette "${name}" applied!`;
        feedback.style.display = 'block';
        setTimeout(() => { feedback.style.display = 'none'; }, 1800);
      }
      showToast(`WLED palette "${name}" applied!`, 'success');
    })
    .catch(err => {
      console.error('Failed to apply WLED palette:', err);
      showToast(`Failed to apply palette: ${err.message}`, 'error');
    });
}

// WLED Effects Modal
window.showWledFxModal = function() {
  const effects = [
    {name:'Rainbow', id: 0},
    {name:'Fireworks', id: 65},
    {name:'Colorloop', id: 51},
    {name:'Breathe', id: 24},
    {name:'Twinkle', id: 20}
  ];
  
  let html = `<div class="modal-header">WLED Effects</div>
    <div class="circular-buttons">`;
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < effects.length; i++) {
    const angle = (i / effects.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button wled-button" style="left: ${x}px; top: ${y}px;" onclick='applyWledEffect(${effects[i].id},"${effects[i].name}")'>
      <div class="icon">✨</div>
      <div class="label">${effects[i].name}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='wledFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModal(html, true);
}

window.applyWledEffect = function(id, name) {
  // Apply to LRWall WLED device
  fetch(`http://${WLED_DEVICES.lrwall}/win&FX=${id}`)
    .then(() => {
      const feedback = document.getElementById('wledFeedback');
      if (feedback) {
        feedback.textContent = `Effect "${name}" applied!`;
        feedback.style.display = 'block';
        setTimeout(() => { feedback.style.display = 'none'; }, 1800);
      }
      showToast(`WLED effect "${name}" applied!`, 'success');
    })
    .catch(err => {
      console.error('Failed to apply WLED effect:', err);
      showToast(`Failed to apply effect: ${err.message}`, 'error');
    });
}

function bubbleChartBubbleClick(label, id) {
  if (['452','449','446','470'].includes(id)) {
    openDeviceModal(label, id, true);
  } else if (id === 'scenes') {
    showScenesModal();
  } else if (id === 'wled') {
    showWledEffectsModal();
  } else if (id === 'global') {
    showGlobalControlsModal();
  } else {
    showModal(`<div class="modal-header">${label}</div>
      <div style="text-align: center; color: #ccc;">Controls for <b>${label}</b> coming soon...</div>`, true);
  }
}

// Global Controls Modal - Uses LRGroup
function showGlobalControlsModal() {
  let html = `<div class="modal-header">Global Controls</div>
    <div class="circular-buttons">`;
  
  const buttons = [
    { icon: '🔆', label: 'All On', onclick: "sendGlobalCommand('on')" },
    { icon: '🌙', label: 'All Off', onclick: "sendGlobalCommand('off')" },
    { icon: '🔅', label: 'Dim', onclick: "sendGlobalCommand('setLevel', 30)" },
    { icon: '☀️', label: 'Bright', onclick: "sendGlobalCommand('setLevel', 100)" }
  ];
  
  // Position buttons in a circle around the perimeter
  const radius = 140; // Distance from center
  const centerX = 240; // Half of modal width (480/2)
  const centerY = 240; // Half of modal height (480/2)
  
  for (let i = 0; i < buttons.length; i++) {
    const angle = (i / buttons.length) * 2 * Math.PI;
    const x = centerX + radius * Math.cos(angle);
    const y = centerY + radius * Math.sin(angle);
    
    html += `<button class="circular-button control-button" style="left: ${x}px; top: ${y}px;" onclick='${buttons[i].onclick}'>
      <div class="icon">${buttons[i].icon}</div>
      <div class="label">${buttons[i].label}</div>
    </button>`;
  }
  
  html += `</div>
    <div id='globalFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
  
  showModal(html, true);
}

function renderGlobalControls(device) {
  const attr = device.attributes || {};
  const isOn = attr.switch === 'on';
  const level = attr.level || 0;
  const hue = attr.hue || 0;
  const sat = attr.saturation || 0;
  
  let html = '';
  
  // Top section with power toggle
  html += `<div style="margin-bottom: 20px;">
    <div style="display: flex; justify-content: center; align-items: center; gap: 16px; margin-bottom: 16px;">
      <button class="circular-button control-button" onclick="sendGlobalCommand('${isOn ? 'off' : 'on'}')" style="background: ${isOn ? 'linear-gradient(135deg, #4caf50 0%, #388e3c 100%)' : 'linear-gradient(135deg, #f44336 0%, #d32f2f 100%)'};">
        <div class="icon">${isOn ? '🔆' : '🌙'}</div>
        <div class="label">${isOn ? 'On' : 'Off'}</div>
      </button>
    </div>
  </div>`;
  
  // Sliders section at bottom
  html += `<div class="modal-sliders">`;
  
  // Brightness slider
  html += `<div class="slider-container">
    <label>Brightness:</label>
    <input type="range" id="globalLevelSlider" min="1" max="100" value="${level}" style="flex:1;">
    <span id="globalLevelVal" class="slider-value">${level}%</span>
  </div>`;
  
  // Color controls
  html += `<div class="slider-container">
    <label>Hue:</label>
    <input type="range" id="globalHueSlider" min="0" max="100" value="${hue}" style="flex:1;">
    <span id="globalHueVal" class="slider-value">${hue}</span>
  </div>`;
  
  html += `<div class="slider-container">
    <label>Saturation:</label>
    <input type="range" id="globalSatSlider" min="0" max="100" value="${sat}" style="flex:1;">
    <span id="globalSatVal" class="slider-value">${sat}</span>
  </div>`;
  
  html += `</div>`;
  
  // Refresh button
  html += `<div style="position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%);">
    <button id='globalRefreshBtn' class='circular-button control-button' style="width: 60px; height: 60px;">
      <div class="icon">🔄</div>
      <div class="label">Refresh</div>
    </button>
  </div>`;
  
  document.getElementById('globalControls').innerHTML = html;
  
  // Event listeners
  document.getElementById('globalLevelSlider').oninput = function() {
    document.getElementById('globalLevelVal').textContent = this.value + '%';
  };
  document.getElementById('globalLevelSlider').onchange = function() {
    sendGlobalCommand('setLevel', this.value);
  };
  
  document.getElementById('globalHueSlider').oninput = function() {
    document.getElementById('globalHueVal').textContent = this.value;
  };
  document.getElementById('globalHueSlider').onchange = function() {
    sendGlobalCommand('setHue', this.value);
  };
  
  document.getElementById('globalSatSlider').oninput = function() {
    document.getElementById('globalSatVal').textContent = this.value;
  };
  document.getElementById('globalSatSlider').onchange = function() {
    sendGlobalCommand('setSaturation', this.value);
  };
  
  document.getElementById('globalRefreshBtn').onclick = function() {
    document.getElementById('globalControls').innerHTML = '<em>Refreshing...</em>';
    fetch(`${MAKER_API_BASE}/devices/${LRGROUP_ID}?access_token=${ACCESS_TOKEN}`)
      .then(res => res.json())
      .then(device => {
        renderGlobalControls(device);
      })
      .catch(err => {
        document.getElementById('globalControls').innerHTML = `<span style='color:red'>Failed to refresh global state.</span>`;
      });
  };
}

window.sendGlobalCommand = function(command, value) {
  let url = `${MAKER_API_BASE}/devices/${LRGROUP_ID}/${command}`;
  if (value !== undefined) url += `/${value}`;
  url += `?access_token=${ACCESS_TOKEN}`;
  
  fetch(url)
    .then(res => res.json())
    .then(data => {
      const feedback = document.getElementById('globalFeedback');
      if (feedback) {
        feedback.textContent = `Global command "${command}" sent!`;
        feedback.style.display = 'block';
        setTimeout(() => { feedback.style.display = 'none'; }, 1800);
      }
      showToast(`Global command sent successfully!`, 'success');
    })
    .catch(err => {
      console.error('Failed to send global command:', err);
      showToast(`Failed to send command: ${err.message}`, 'error');
    });
}

// Scene Manager for handling scene-related functionality
const sceneManager = {
  getScenePreviewHTML() {
    let html = `<div class="modal-header">Choose a Scene</div>
      <div class="circular-buttons">`;
    
    // Position buttons in a circle around the perimeter
    const radius = 140; // Distance from center
    const centerX = 240; // Half of modal width (480/2)
    const centerY = 240; // Half of modal height (480/2)
    
    for (let i = 0; i < lifxScenes.length; i++) {
      const angle = (i / lifxScenes.length) * 2 * Math.PI;
      const x = centerX + radius * Math.cos(angle);
      const y = centerY + radius * Math.sin(angle);
      
      html += `<button class="circular-button scene-button" style="left: ${x}px; top: ${y}px;" onclick='applyLifxScene("${lifxScenes[i].name}")'>
        <div class="icon">🎨</div>
        <div class="label">${lifxScenes[i].name}</div>
      </button>`;
    }
    
    html += `</div>
      <div id='sceneFeedback' style='position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); font-size: 1.1em; color: #fff; display: none;'></div>`;
    
    return html;
  }
};

// Export for use in other modules
export { sceneManager }; 